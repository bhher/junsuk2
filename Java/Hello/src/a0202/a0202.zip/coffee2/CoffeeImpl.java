package a0202.coffee2;

public class CoffeeImpl {
    public static void main(String[] args) {
        CoffeeService coffeeService = new CoffeeService();
        coffeeService.start();
        //프로그램 시작(기동)
    }
}
