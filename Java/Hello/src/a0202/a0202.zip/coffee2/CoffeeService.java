package a0202.coffee2;

import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class CoffeeService {
    private boolean reOrder = false;
    private int orderNum = 1;
    Map<String,Integer>orderList;

    public CoffeeService() {
        orderList = new LinkedHashMap<>();
    }
    //고객주문 저장 orderList
    //new LinkedHashMap<>(); 입력순서 또는 접근 순서 보장 -> 느림
    //용도는 순서가 중요한 경우 사용

    Coffee coffee = Coffee.getInstance();
    //커피 메뉴 를 관리하는 싱글톤객체(프로그램에서 한개만 존재)
    //new Coffee(); 가 생성하는게 아님
    Customer customer;

    Thread t = new Thread(); //스레드
    //사용자가 처리할 프로그램 지정
    //여기선 지연 클래스 사용할 것임

    Scanner sc = new Scanner(System.in);

    public void start(){
        System.out.println("\n 어서오세요 더조은 커피숍입니다.");
        customer = new Customer(orderNum); //주문번호 , 잔액
        coffee.getMenu();
        order();//주문메서드
        totalOrder(customer);
       try {
           System.out.println("기다려 주시면 주문하신 음료가 나옵니다.");
           t.sleep(2000);
           //2초후 다움 문장 실행
           end();
       } catch (Exception e) {
          e.printStackTrace();
       }

    }

    private void end() {
         int s = 1;
        StringBuffer message = new StringBuffer();
        message.append("\n\n ")
                .append("+----------------------------------------------------+\n ")
                .append("|                                                    | \n ")
                .append("|           " + customer.getOrderName() + " 고객님 주문하신 음료 나왔습니다         | " + "\n");
        System.out.print(message);
        for(Map.Entry<String, Integer> order : customer.getCoffeeOrder().entrySet() ){
            System.out.printf(" | [%d] %-20s : %2d잔  %7s |\n", s, order.getKey(), order.getValue(), "");
            s++;
        }
        System.out.println(" |                                                    |");
        System.out.println(" +----------------------------------------------------+");
    }

    private void totalOrder(Customer customer2) {
       int s = 1;
       int totalMoney = 0;
       int coffeePrice = 0;
       DecimalFormat f = new DecimalFormat("###,000원");
       String name = customer.getOrderName() + "번";  
        StringBuffer message = new StringBuffer();
            message.append("\n\n ")
            .append("+----------------------------------------------------+\n ")
            .append("|                                                    | \n ")
            .append("|             " + name + "고객님 의 주문 내역 입니다         | " + "\n");
        for(Map.Entry<String, Integer> order : customer.getCoffeeOrder().entrySet()){
            String coffeeName = order.getKey();
            int orderCount = order.getValue(); 
            int coffeeUnitPrice = coffee.menu.get(coffeeName); //커피객단가
            //Americano  3000
            //.get(coffeeName) : 커피이름으로 값을 조회
            coffeePrice = coffeeUnitPrice  * orderCount; //객단가 * 주문수량
            totalMoney = totalMoney +  coffeePrice; //전체 커피가격
            String pay = f.format(coffeePrice); //가격이 포맷팅
            message.append(String.format(" | [%d] %-20s : %2d잔  %7s |\n", s, coffeeName, orderCount, pay));
            s++; // 리스트 인덱스 증가
        }
          message.append(" |                                                    |\n ")
            .append("+----------------------------------------------------+ \n")
            .append(" ============ 총 결제 금액은 " + f.format(totalMoney) + "입니다 ========== \n");
            System.out.println(message);
            payment(totalMoney);


    }

    private void payment(int totalMoney) {
      System.out.println("\n결재를 도와 드리겠습니다. 카드를 넣어주세요");
      int payResult = customer.getMoney() - totalMoney;//고객잔고 - 결재총금액
        try {
            System.out.println("\n결재중입니다.");
            t.sleep(2000);// 2초후 실행

        } catch (Exception e) {
            e.printStackTrace(); //예외 발생메세지 자바가 알아서 출력
        }
        if(payResult  < 0){
            System.out.println("잔액부족, 주문 다시해주세요");
        }else{
            customer.setMoney(payResult); //결제후 잔액을 고객잔고에 넣어놓기
            System.out.println("결제가 완료되었습니다.");
            System.out.println("이용해 주셔서 감사합니다.");
            orderNum++; //고객번호 증가
        }
    }


    private void order() {
        System.out.println("\n 취소를 원하시면 0번을 눌러 주세요");
        end:while (true) {//while 탈출명령(end)
            try {
                
          
            System.out.println("\n원하는 음료의 번호를 선택해주세요");
            String choice = sc.next();
            int choiceNum = Integer.parseInt(choice.substring(0,1));
            //인덱스번호 0 번 한글자만 추출해서 숫자로 변경
            if(choiceNum == 0){
                System.out.println("주문을 취소합니다.");
                System.exit(0);//주문을 빠져나감
            }
            sc.nextLine(); //버퍼지우기

            String coffeeName = coffee.coffeeList.get(choiceNum-1); 
            System.out.println("선택하신 음료는 "+coffeeName+"입니다.  몇 잔 주문?");
            int orderCount = sc.nextInt();
            sc.nextLine();

            //재주문 if문
            if(reOrder){ //true -> 이미 주문한 커피인지 확인 
                for(String coff : orderList.keySet()){
                    if(coff.equals(coffeeName)){ //똑같은 커피를 주문 한다면
                        int addCount = orderList.get(coff).intValue()+ orderCount;
                        //.intValue() 는 Integer -> int 변환 -> 요즘자바에서는 생략가능
                        //주문 리스트의 수량을 불러서 현재 수량에 더한다.(기존수량+새주문 수량)
                        orderList.replace(coffeeName, addCount);
                        //replace -> arrayList 지원하는 변환 메서드
                    }else{
                        orderList.put(coffeeName, orderCount);
                        break;
                    }
                }
             }else{
                orderList.put(coffeeName, orderCount);
            }
            customer.setCoffeeOrder(orderList); //커피이름 , 수량을 주문리스트에 담아서 저장
            //추가주문 
            addOrder();
            break end;
            } catch (Exception e) {
               System.out.println("잘못된 선택입니다.");
            }
        }

    }

    private void addOrder() {
       reOrder = false;
       System.out.println("\n주문을 계속 하시겠습니까?");
       System.out.println("예(Y)/아니오(N)");
       String yesOrNo = sc.next();
       if(yesOrNo.equals("예") || yesOrNo.equalsIgnoreCase("y")){
         coffee.getMenu();
         reOrder = true;
         order();
       }else if(yesOrNo.equals("아니오") || yesOrNo.equalsIgnoreCase("n")){
          return;
       }

    }

}
