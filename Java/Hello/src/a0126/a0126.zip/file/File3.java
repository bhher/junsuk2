package a0126.file;


import java.io.IOException;
import java.io.PrintWriter;

public class File3 {
    public static void main(String[] args) throws IOException {
        PrintWriter pw  = new PrintWriter("c:/Users/TJ/out.txt","UTF-8");
        for(int i = 1; i < 11; i++){
            String data = i + " 번째 줄입니다.";
            pw.println(data);
        }
        pw.close();
    }
}
