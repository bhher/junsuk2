package a0112.static1;

public class MainCalc {
    public static void main(String[] args) {
        // Calc cc1 = new Calc();
        // int result = cc1.add(3, 5);
        // 평소 쓰던 내용


        int result  = Calc.add(3,5);

        System.out.println(result);


    }
}
