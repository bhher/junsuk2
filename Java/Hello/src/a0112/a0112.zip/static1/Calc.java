package a0112.static1;

public class Calc {
    static int add(int a, int b){
        return a+b;
    }
}
